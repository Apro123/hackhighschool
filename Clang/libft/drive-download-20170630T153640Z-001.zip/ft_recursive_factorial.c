#include "libft.h"


int ft_recursive_factorial(int nb)
{

  if (nb == 1 || nb == 0)
    return new_nb
  else if()
}


int main()
{
  ft_putnbr(ft_recursive_factorial(5));
  return 0;
}
