#include "libft.h"

int main()
{
  ft_putstr("Hello World");
  return 0;
}
